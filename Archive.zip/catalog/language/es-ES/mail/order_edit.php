<?php
$_['text_subject'] 	=  ' %s - Actualización de pedidos %s';
$_['text_order_id'] 	=  'Solicitar ID:';
$_['text_date_added'] 	=  'Fecha Agregada:';
$_['text_order_status'] 	=  'Su pedido se ha actualizado con el siguiente estado:';
$_['text_comment'] 	=  'Los comentarios para su pedido son:';
$_['text_link'] 	=  'Para ver su pedido haga clic en el siguiente enlace:';
$_['text_footer'] 	=  'Responda a este correo electrónico si tiene alguna pregunta.';
