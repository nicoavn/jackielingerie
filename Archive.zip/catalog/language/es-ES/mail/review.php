<?php
$_['text_subject'] 	=  ' %s - Revisión del producto';
$_['text_waiting'] 	=  'Usted tiene una nueva revisión del producto esperando.';
$_['text_product'] 	=  'Producto: %s';
$_['text_reviewer'] 	=  'Revisor: %s';
$_['text_rating'] 	=  'Clasificación: %s';
$_['text_review'] 	=  'Texto de la revisión:';
