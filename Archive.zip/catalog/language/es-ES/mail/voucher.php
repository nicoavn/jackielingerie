<?php
$_['text_subject'] 	=  'Se le ha enviado un certificado de regalo de %s';
$_['text_greeting'] 	=  'Enhorabuena, has recibido un Certificado de Regalo por valor de %s';
$_['text_from'] 	=  'Este certificado de regalo le ha sido enviado por %s';
$_['text_message'] 	=  'Con un mensaje diciendo';
$_['text_redeem'] 	=  'Para canjear este Certificado de Regalo, anote el código de canje que es <b> %s </ b> y luego haga clic en el enlace de abajo y compre el producto en el que desea usar este certificado de regalo. Puede ingresar el código del certificado de regalo en la página del carrito de la compra antes de hacer clic en el proceso de pago.';
$_['text_footer'] 	=  'Por favor, responda a este correo electrónico si tiene alguna pregunta.';
