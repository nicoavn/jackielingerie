<?php
$_['text_success'] 	=  'Éxito: Se ha aplicado el descuento de cupón.';
$_['error_permission'] 	=  'Advertencia: ¡No tiene permiso para acceder a la API!';
$_['error_coupon'] 	=  'Advertencia: ¡El cupón no es válido, ha caducado o ha llegado a su límite de uso!';
