<?php
$_['text_success'] 	=  'Éxito: ¡Has modificado tu carrito de compras!';
$_['error_permission'] 	=  'Advertencia: ¡No tiene permiso para acceder a la API!';
$_['error_stock'] 	=  '¡Los productos marcados con *** no están disponibles en la cantidad deseada o no en stock!';
$_['error_minimum'] 	=  'La cantidad mínima de pedido para %s es %s!';
$_['error_store'] 	=  '¡El producto no se puede comprar en la tienda que ha elegido!';
$_['error_required'] 	=  'Se requiere %s!';
