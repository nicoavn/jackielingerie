<?php
$_['heading_title'] 	=  'Mapa del sitio';
$_['text_special'] 	=  'Ofertas especiales';
$_['text_account'] 	=  'Mi cuenta';
$_['text_edit'] 	=  'Información de la cuenta';
$_['text_password'] 	=  'Contraseña';
$_['text_address'] 	=  'Directorio';
$_['text_history'] 	=  'Historial de pedidos';
$_['text_download'] 	=  'Descargas';
$_['text_cart'] 	=  'Carrito de compras';
$_['text_checkout'] 	=  'Completar la orden';
$_['text_search'] 	=  'Buscar';
$_['text_information'] 	=  'Información';
$_['text_contact'] 	=  'Contáctenos';
