<?php
// Heading
$_['heading_title'] = 'Usar Código de Cupón';

// Text
$_['text_coupon']   = 'Cupón (%s)';
$_['text_success']  = 'Éxito: ¡Su cupón de descuento ha sido aplicado!';

// Entry
$_['entry_coupon']  = 'Teclee su cupón aquí';

// Error
$_['error_coupon']  = 'Advertencia: ¡El Cupón no es válido, caducó o alcanzó el límite de uso!';
$_['error_empty']   = 'Advertencia: ¡Teclee un código de cupón por favor!';
