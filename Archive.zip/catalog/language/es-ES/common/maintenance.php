<?php
$_['heading_title'] 	=  'Mantenimiento';
$_['text_maintenance'] 	=  'Mantenimiento';
$_['text_message'] 	=  '<H1 style = "text-align: center;"> Actualmente estamos realizando algún mantenimiento programado. <br/> Volveremos lo antes posible. Por favor vuelva pronto. </ H1>';
