<?php
$_['text_search'] 	=  'Buscar';
