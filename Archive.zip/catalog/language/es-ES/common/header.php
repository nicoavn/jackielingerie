<?php
$_['text_home'] 	=  'Inicio';
$_['text_wishlist'] 	=  'Listas de deseos';
$_['text_shopping_cart'] 	=  'Mi carrito';
$_['text_category'] 	=  'Categorías';
$_['text_account'] 	=  'Login';
$_['text_register'] 	=  'Registro';
$_['text_login'] 	=  'Iniciar sesión';
$_['text_order'] 	=  'Historial de pedidos';
$_['text_transaction'] 	=  'Transacción';
$_['text_download'] 	=  'Descargas';
$_['text_logout'] 	=  'Cerrar sesión';
$_['text_checkout'] 	=  'Pagar';
$_['text_search'] 	=  'Buscar';
$_['text_all'] 	=  'Mostrar todo';
