<?php
$_['text_items'] 	=  '%s artículo(s) - %s';
$_['text_empty'] 	=  '¡Su cesta está vacía!';
$_['text_cart'] 	=  'Ver Carro';
$_['text_checkout'] 	=  'Completar la orden';
$_['text_recurring'] 	=  'Perfil de pago';
