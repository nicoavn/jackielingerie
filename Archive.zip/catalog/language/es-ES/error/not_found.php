<?php
$_['heading_title'] 	=  '¡La página solicitada no pudo ser encontrada!';
$_['text_error'] 	=  'La página solicitada no pudo ser encontrada.';
