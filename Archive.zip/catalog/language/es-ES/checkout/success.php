<?php
$_['heading_title'] 	=  '¡Su orden ha sido enviada!';
$_['text_basket'] 	=  'Carrito de compras';
$_['text_checkout'] 	=  'Completar la orden';
$_['text_success'] 	=  'Éxito';
$_['text_customer'] 	=  '<p> ¡Su pedido se ha procesado correctamente! </p> <p> Puede ver su historial de pedidos visitando la página <a href="%s"> mi cuenta </a> y haciendo clic en <a href="%s">historial</a>.</p><p> Si tiene alguna duda o comentario, por favor <a href="%s"> contáctenos </a>. </p> <p> ¡Gracias por comprar en Jackie Lingerie! </p>';
$_['text_guest'] 	=  '<p> ¡Su pedido se ha procesado correctamente! </p> <p> Si tiene alguna duda o comentario, por favor <a href="%s"> contáctenos </a>. </p> <p> ¡Gracias por comprar en Jackie Lingerie! </p>';
