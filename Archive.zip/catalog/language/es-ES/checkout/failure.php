<?php
$_['heading_title'] 	=  '¡Pago fallido!';
$_['text_basket'] 	=  'Carrito de compras';
$_['text_checkout'] 	=  'Completar la orden';
$_['text_failure'] 	=  'Pago fallido';
$_['text_message'] 	=  '<p> Hubo un problema al procesar su pago y el pedido no se completó. </p>

<p> Las razones posibles son: </ p>
<Ul>
  <Li> Fondos insuficientes </ li>
  <Li> Error de verificación </ li>
</ Ul>

<p> Intente ordenar de nuevo utilizando un método de pago diferente. </p>

<p> Si el problema persiste, <a href="%s"> póngase en contacto con nosotros </a> con los detalles del pedido que está intentando colocar. </p>';
