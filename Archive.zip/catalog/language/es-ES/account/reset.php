<?php
$_['heading_title'] 	=  'Restablecer su contraseña';
$_['text_account'] 	=  'Cuenta';
$_['text_password'] 	=  'Ingrese la nueva contraseña que desea usar.';
$_['text_success'] 	=  'Éxito: su contraseña se ha actualizado correctamente.';
$_['entry_password'] 	=  'Contraseña';
$_['entry_confirm'] 	=  'Confirmar';
$_['error_password'] 	=  '¡La contraseña debe tener entre 4 y 20 caracteres!';
$_['error_confirm'] 	=  'Confirmación de contraseña y contraseña no coinciden!';
$_['error_code'] 	=  '¡El código de restablecimiento de contraseña no es válido o se usó anteriormente!';
