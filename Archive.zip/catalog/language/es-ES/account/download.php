<?php
$_['heading_title'] 	=  'Descargas de la cuenta'; 
$_['text_account'] 	=  'Cuenta'; 
$_['text_downloads'] 	=  'Descargas'; 
$_['text_empty'] 	=  '¡No ha realizado pedidos anteriores descargables!'; 
$_['column_order_id'] 	=  'Solicitar ID'; 
$_['column_name'] 	=  'Nombre'; 
$_['column_size'] 	=  'tamaño'; 
$_['column_date_added'] 	=  'Fecha Agregada'; 
