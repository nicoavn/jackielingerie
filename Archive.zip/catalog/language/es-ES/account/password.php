<?php
$_['heading_title'] 	=  'Cambia la contraseña';
$_['text_account'] 	=  'Cuenta';
$_['text_password'] 	=  'Tu contraseña';
$_['text_success'] 	=  'Éxito: su contraseña se ha actualizado correctamente.';
$_['entry_password'] 	=  'Contraseña';
$_['entry_confirm'] 	=  'Contraseña confirmada';
$_['error_password'] 	=  '¡La contraseña debe tener entre 4 y 20 caracteres!';
$_['error_confirm'] 	=  '¡La confirmación de la contraseña no coincide con la contraseña!';
