<?php
$_['heading_title'] 	=  'Seguimiento de afiliados';
$_['text_account'] 	=  'Cuenta';
$_['text_description'] 	=  'Para cerciorarse de que usted consiga pagado por referencias que usted nos envía necesitamos seguir la referencia colocando un código de seguimiento en la URL que liga a nosotros. Puede utilizar las herramientas siguientes para generar enlaces al sitio web de %s.';
$_['entry_code'] 	=  'Su código de seguimiento';
$_['entry_generator'] 	=  'Generador de vínculos de seguimiento';
$_['entry_link'] 	=  'Enlace de seguimiento';
$_['help_generator'] 	=  'Escriba el nombre de un producto al que desea enlazar';
