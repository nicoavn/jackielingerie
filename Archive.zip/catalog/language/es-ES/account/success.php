<?php
$_['heading_title'] 	=  '¡Tu cuenta ha sido creada!';
$_['text_message'] 	=  '<p> ¡Felicitaciones! ¡Su nueva cuenta se ha creado con éxito! </p> <p> Ahora puede aprovechar los privilegios de los miembros para mejorar su experiencia de compra en línea. </p> <p> Si tiene CUALQUIER pregunta sobre el funcionamiento de esta página en línea Tienda, por favor envíe un correo electrónico al dueño de la tienda. </p> <p> Se ha enviado una confirmación a la dirección de correo electrónico proporcionada. Si no lo ha recibido en una hora, <a href="%s"> póngase en contacto con nosotros </a>. </p>';
$_['text_approval'] 	=  '<p> Gracias por registrarse en %s! </p> <p> Se le notificará por correo electrónico una vez que su cuenta haya sido activada por el propietario de la tienda. </p> <p> Si tiene CUALQUIER pregunta acerca de El funcionamiento de esta tienda en línea, <a href="%s"> póngase en contacto con el propietario de la tienda </a>. </p>';
$_['text_account'] 	=  'Cuenta';
$_['text_success'] 	=  'Éxito';
