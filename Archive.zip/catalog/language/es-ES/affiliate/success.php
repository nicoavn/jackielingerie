<?php
$_['heading_title'] 	=  'Su cuenta de afiliado ha sido creada!';
$_['text_message'] 	=  '<p> ¡Felicitaciones! Tu nueva cuenta ha sido creada con éxito. </p> <p> Ahora eres miembro de afiliados de %s. </p> <p> Si tienes CUALQUIER pregunta sobre el funcionamiento de este sistema de afiliados, envía un correo electrónico a Propietario de la tienda. </p> <p> Se ha enviado una confirmación a la dirección de correo electrónico proporcionada. Si no lo ha recibido en una hora, <a href="%s"> póngase en contacto con nosotros </a>. </p>';
$_['text_approval'] 	=  '<p> Gracias por registrarte en una cuenta de afiliado con %s! </p> <p> Se te notificará por correo electrónico una vez que tu cuenta haya sido activada por el propietario de la tienda. Tiene CUALQUIER pregunta sobre el funcionamiento de este sistema de afiliados, <a href="%s"> póngase en contacto con el propietario de la tienda </a>. </p>';
$_['text_account'] 	=  'Cuenta';
$_['text_success'] 	=  'Éxito';
