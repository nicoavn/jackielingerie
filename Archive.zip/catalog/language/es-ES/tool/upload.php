<?php
$_['text_upload'] 	=  '¡Tu archivo se ha cargado correctamente!';
$_['error_filename'] 	=  '¡El nombre de archivo debe tener entre 3 y 64 caracteres!';
$_['error_filetype'] 	=  '¡Tipo de archivo invalido!';
$_['error_upload'] 	=  '¡Se requiere subir!';
