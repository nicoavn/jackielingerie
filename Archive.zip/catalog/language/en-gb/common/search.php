<?php
// Text
$_['text_search'] = 'Search';