<?php
// Text
$_['text_information']  = 'Information';
$_['text_service']      = 'Customer Assistance';
$_['text_extra']        = 'Connect';
$_['text_contact']      = 'Contact Us';
$_['text_return']       = 'Returns and changes';
$_['text_sitemap']      = 'Site Map';
$_['text_manufacturer'] = 'Brands';
$_['text_voucher']      = 'Gift Certificates';
$_['text_affiliate']    = 'Affiliate';
$_['text_special']      = 'Specials';
$_['text_account']      = 'My Account';
$_['text_order']        = 'Order History';
$_['text_wishlist']     = 'Wish List';
$_['text_newsletter']   = 'Newsletter';
$_['text_assistance']   = 'Quick assistance';
$_['text_date']   		= 'Service Hours';
$_['text_weekday']   	= 'Weekday <br>From 10:00 to 20:00';
$_['text_saturdays']   	= 'Saturdays <br>From 10:00 to 16:00';
$_['txt_holidays']   	= 'Closed on public holidays Spanish nationals';
$_['text_Customer'] 	=  'Customer Assistance and Services';
$_['text_enter'] 	=  '<br> ';
$_['text_powered']      = '%s &copy;%s All rights reserved. Powered By <a href="https://www.instagram.com/methedesigner/" target="_blank">me the designer</a>';

